from enum import Enum


class House(Enum):
    Bungalow = 1
    Flat = 2
    Duplex = 3
    FaceMeIFaceYou = 4