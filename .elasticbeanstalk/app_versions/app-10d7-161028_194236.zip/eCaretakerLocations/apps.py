from django.apps import AppConfig


class EcaretakerlocationsConfig(AppConfig):
    name = 'eCaretakerLocations'
