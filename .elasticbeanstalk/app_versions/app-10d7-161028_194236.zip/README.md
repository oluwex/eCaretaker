# eCaretaker

This project aims to bring home owners and tenants closer together by providing an online platform through which issues are raised and addressed, discussions are made and problems discussed.
