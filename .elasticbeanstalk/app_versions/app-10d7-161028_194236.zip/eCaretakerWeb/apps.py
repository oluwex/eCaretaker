from django.apps import AppConfig


class EcaretakerwebConfig(AppConfig):
    name = 'eCaretakerWeb'
